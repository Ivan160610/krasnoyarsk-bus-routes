import {createServer} from 'node:http';
import {pathToFileURL} from 'node:url';
import {handlePortal} from './server-core.mjs';

function publicOrigin(){
  const url=new URL(process.env.PUBLIC_ORIGIN || 'http://127.0.0.1:3000');
  const local=['localhost','127.0.0.1'].includes(url.hostname);
  if(url.username||url.password||url.pathname!=='/'||url.search||url.hash||
    (url.protocol!=='https:'&&!(local&&process.env.ALLOW_LOCAL_HTTP==='1')))
    throw Error('Set PUBLIC_ORIGIN to the exact HTTPS address of this portal.');
  return url.origin;
}

export function createPortalServer(origin=publicOrigin()){
  return createServer(async(req,res)=>{
    try{
      const url=new URL(req.url,origin);
      if(url.origin!==origin){res.writeHead(400);return res.end('Invalid address')}
      if(url.pathname==='/health'&&req.method==='GET'){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});return res.end('{"ok":true}')}
      if(url.pathname==='/activate'||url.pathname==='/signin-with-chatgpt'){
        res.writeHead(200,{'Content-Type':'text/html; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'});
        return res.end('<!doctype html><html lang="ru"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Доступ администратора</title><style>body{font:16px system-ui;max-width:520px;margin:60px auto;padding:24px;color:#173c36;background:#edf3ef}a{color:#176e58}</style><h1>Доступ администратора</h1><p>Для настройки или восстановления учётной записи обратитесь к ответственному за размещение кабинета.</p><p><a href="/login">Вернуться ко входу</a> · <a href="/">Открыть карту</a></p></html>');
      }
      const headers=new Headers();
      for(const[name,value]of Object.entries(req.headers)){
        if(name.startsWith('oai-')||['host','connection','content-length','cf-connecting-ip','x-forwarded-for','x-forwarded-host','x-forwarded-proto'].includes(name))continue;
        if(typeof value==='string')headers.set(name,value);
      }
      headers.set('CF-Connecting-IP',req.socket.remoteAddress||'unknown');
      let body;
      if(!['GET','HEAD'].includes(req.method)){
        const limit=2_000_000;
        if(Number(req.headers['content-length'])>limit){res.writeHead(413,{'Content-Type':'application/json'});res.end('{"error":"Слишком большой файл"}');req.resume();return}
        const chunks=[];let size=0;
        for await(const chunk of req){size+=chunk.length;if(size>limit){res.writeHead(413,{'Content-Type':'application/json'});res.end('{"error":"Слишком большой файл"}');return}chunks.push(chunk)}
        body=Buffer.concat(chunks);
      }
      const response=await handlePortal(new Request(url,{method:req.method,headers,...(body?{body}: {})}));
      const outputHeaders={};for(const[name,value]of response.headers)if(name!=='set-cookie')outputHeaders[name]=value;
      const cookies=response.headers.getSetCookie();if(cookies.length)outputHeaders['set-cookie']=cookies;
      res.writeHead(response.status,outputHeaders);res.end(Buffer.from(await response.arrayBuffer()));
    }catch(error){
      console.error(JSON.stringify({event:'request_failed',method:req.method,error:error.name}));
      if(!res.headersSent)res.writeHead(503,{'Content-Type':'application/json','Cache-Control':'no-store'});
      res.end('{"error":"Сервис временно недоступен. Черновик сохранён в браузере."}');
    }
  });
}
if(process.argv[1]&&pathToFileURL(process.argv[1]).href===import.meta.url){
  const port=Number(process.env.PORT||3000);createPortalServer().listen(port,'0.0.0.0',()=>console.log(`Route portal listening on port ${port}`));
}
