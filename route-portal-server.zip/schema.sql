CREATE TABLE IF NOT EXISTS `route_admins` (
	`login` text PRIMARY KEY NOT NULL,
	`password_hash` text NOT NULL,
	`owner_id` text NOT NULL,
	`created_at` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `route_current` (
	`id` integer PRIMARY KEY NOT NULL,
	`revision` text NOT NULL,
	`document` text NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `route_login_attempts` (
	`key` text PRIMARY KEY NOT NULL,
	`attempts` integer NOT NULL,
	`until` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `route_sessions` (
	`token_hash` text PRIMARY KEY NOT NULL,
	`login` text NOT NULL,
	`csrf` text NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE TABLE IF NOT EXISTS `route_versions` (
	`revision` text PRIMARY KEY NOT NULL,
	`document` text NOT NULL,
	`created_at` text NOT NULL,
	`login` text NOT NULL,
	`comment` text NOT NULL
);
