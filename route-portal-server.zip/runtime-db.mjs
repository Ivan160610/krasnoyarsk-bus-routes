import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,readFileSync} from 'node:fs';
import {dirname,resolve} from 'node:path';
import {fileURLToPath} from 'node:url';

const here=dirname(fileURLToPath(import.meta.url));
const path=process.env.ROUTE_DATABASE || resolve(process.env.DATA_DIR || resolve(here,'data'),'routes.sqlite');
if(path!==':memory:')mkdirSync(dirname(path),{recursive:true});
export const sqlite=new DatabaseSync(path);
sqlite.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000;');
sqlite.exec(readFileSync(new URL('./schema.sql',import.meta.url),'utf8'));

function prepare(sql){
  let values=[];
  const runSync=()=>{const result=sqlite.prepare(sql).run(...values);return {meta:{changes:Number(result.changes)}}};
  return {bind(...next){values=next;return this},runSync,
    async first(){return sqlite.prepare(sql).get(...values)||null},
    async all(){return {results:sqlite.prepare(sql).all(...values)}},async run(){return runSync()}};
}
export const DB={prepare,batch(statements){
  sqlite.exec('BEGIN IMMEDIATE');
  try{const results=statements.map(s=>s.runSync());sqlite.exec('COMMIT');return Promise.resolve(results)}
  catch(error){sqlite.exec('ROLLBACK');return Promise.reject(error)}
}};
// No external identity header can activate or reset the local administrator.
export const env={DB};
