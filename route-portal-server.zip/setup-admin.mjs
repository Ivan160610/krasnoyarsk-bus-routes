import {createInterface} from 'node:readline/promises';
import {Writable} from 'node:stream';
import {sqlite,DB} from './runtime-db.mjs';
import {hashPassword} from './server-core.mjs';

if(!process.stdin.isTTY)throw Error('Run this command in an interactive terminal. Never pass a password as an argument.');
const reset=process.argv.includes('--reset');
if(sqlite.prepare('SELECT login FROM route_admins WHERE login=?').get('Ivan160610')&&!reset)throw Error('Administrator already exists. Initial setup will not overwrite an existing account. Use --reset only to deliberately reset its password and sessions.');
let muted=false;
const output=new Writable({write(chunk,encoding,callback){if(!muted)process.stdout.write(chunk,encoding);callback()}});
const input=createInterface({input:process.stdin,output,terminal:true});
async function ask(label){process.stdout.write(label);muted=true;try{return await input.question('')}finally{muted=false;process.stdout.write('\n')}}
try{
  const password=await ask('Пароль для Ivan160610: '),confirm=await ask('Повторите пароль: ');
  if(password!==confirm)throw Error('Пароли не совпадают.');
  const hash=await hashPassword(password);
  await DB.batch([
    DB.prepare('INSERT INTO route_admins(login,password_hash,owner_id,created_at) VALUES(?,?,?,?) ON CONFLICT(login) DO UPDATE SET password_hash=excluded.password_hash').bind('Ivan160610',hash,'local-owner',new Date().toISOString()),
    DB.prepare('DELETE FROM route_sessions'),DB.prepare('DELETE FROM route_login_attempts')
  ]);
  console.log('Учётная запись настроена. Пароль не отображался и не записывался в файлы настройки.');
}finally{input.close();sqlite.close()}
